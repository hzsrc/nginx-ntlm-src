#!/bin/bash

cd nginx-1.19.3/

make
