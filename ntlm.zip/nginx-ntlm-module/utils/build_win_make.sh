#!/bin/bash

echo "This command does not run anything!"
echo "You have to execute this commands manually"
echo "1. Open VS x64 Native Tools Command Prompt for VS 2017"
echo "2. cd nginx-1.19.3"
echo "3. nmake"
echo "Take a coffe and wait until is done"
